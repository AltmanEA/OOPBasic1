import { Board, Cell } from "./Board"


export class State {
    board: Board
    sym: Cell

    constructor(
        board: Board = new Board(),
        sym: Cell = "X"
    ) {
    }

    clone(): State {
    }

}