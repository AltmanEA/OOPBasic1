import { State } from "./State"

export class Game {
    steps: State[]
    current: number

    constructor(
        steps: State[] = [new State()],
        current: number = 0
    ) {
    }

    get state(): State {
    }

    clone() {
    }

    move(index: number): boolean {
    }

    toStep(step: number) {
    }
}