import { Game } from "./Game";
import { State } from "./State";

type Saving = {
    key: string
    game: Game
}

export class Site {
    game: Game = new Game()
    Games: Saving[] = []

    save() {
    }

    load(index: number) {
    }

    keys(): string[] {
    }
}