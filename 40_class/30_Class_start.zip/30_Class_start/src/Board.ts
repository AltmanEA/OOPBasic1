export type Cell = "_" | "X" | "0"

export function isCell(sym: string): sym is Cell {
}

export class Board {
    cells: Cell[]

    constructor(str: string | Cell[] = "_________") {
    }

    clone(): Board {
    }

    private static fromString(str: string): Cell[] | null {
    }

    isFill(): boolean {
    }

    move(index: number, cell: Cell): boolean {
    }

    private getLineChar(line: number[]): Cell[] {
        return [this.cells[line[0]], this.cells[line[1]], this.cells[line[2]]];
    }

    private static winPos = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ]

    checkWin() {
    }

    status(): string {
    }
}