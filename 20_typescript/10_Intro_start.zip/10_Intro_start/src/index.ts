import { checkWin, isFill, isRightMove } from "./board"

let resetButton = <HTMLButtonElement>document.getElementById("reset")
let info = <HTMLDivElement>document.getElementById("info")
let buttons: HTMLButtonElement[] = []
let board: string[] = []
for (let i = 0; i < 9; i++) {
    let b = <HTMLButtonElement>document.getElementById("f" + i)
    b.onclick = function (): void { step(i) }
    buttons.push(b)
    let f = b.textContent
    if (f == null) { f = "_" };
    board.push(f)
}
let zeroBoard = board.slice()
let gameOver = false
let turn = "X"

function getTurn(): "X" | "0" {
    if (turn == "X") {
        turn = "0"
        return ("X")
    } else {
        turn = "X"
        return ("0")
    }
}


const reset = function (this: GlobalEventHandlers): void {

}

resetButton.onclick = reset

function step(cell: number): void {

}
