export function boardFromString(s: string): string[] {

}
export function boardToString(b: string[]): string {
}

export function isFill(board: string[]): boolean {
}

export function isRightMove(move: number, board: string[]): boolean {
}

const winPos = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
]


function getLineChar(line: number[], board: string[]): string[] {
    return [board[line[0]], board[line[1]], board[line[2]]]
}

export function checkWin(board: string[]): string {
}